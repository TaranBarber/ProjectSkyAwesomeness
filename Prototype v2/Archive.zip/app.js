   document.addEventListener('polymer-ready', function() {
      var navicon = document.getElementById('navicon');
      var drawerPanel = document.getElementById('drawerPanel');

      navicon.addEventListener('click', function() {
        drawerPanel.togglePanel();
      });

   });