angular.module('starApp')
.controller('LessonCtrl', function($scope){
	$scope.lesson = '';
});